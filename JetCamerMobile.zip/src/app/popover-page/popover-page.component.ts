import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popover-page',
  templateUrl: './popover-page.component.html',
  styleUrls: ['./popover-page.component.scss'],
})
export class PopoverPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
