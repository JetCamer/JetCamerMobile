(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~tab1-tab1-module~tab2-tab2-module~tab3-tab3-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/explore-container/explore-container.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/explore-container/explore-container.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-list lines=\"none\" class=\"container\">\n\n  <div class=\"white-bg-top\">\n    <!--\n    <ion-item class=\"header\">\n      <ion-label class=\"ion-text-center\" color=\"dark\">\n        <h1> <strong>Narcisse NOUMEGNI</strong> </h1>\n        <span> <ion-icon name=\"location\" color=\"primary\"></ion-icon> <strong>Douala - Cameroon </strong> </span>\n      </ion-label>\n    </ion-item>  \n    -->\n    <ion-item class=\"header\">\n      <ion-label class=\"ion-text-center\" color=\"dark\">\n        <h1> <strong>JETCAMER</strong> </h1>\n        <span> <strong>Version 2.0.0</strong> </span>\n      </ion-label>\n    </ion-item>  \n    <div class=\"vertical-center\">\n      <ion-icon name=\"person-circle-sharp\" size=\"large\" class=\"logo\" color=\"light\"></ion-icon>\n    </div>  \n  </div>\n  <div class=\"box\">\n    <ion-grid>\n      <ion-row>\n        <ion-col class=\"ion-text-center\">\n          <ion-button expand=\"full\" fill=\"outlined\" style=\"height: 75px;\">\n            <ion-label color=\"light\"> \n              <ion-text>Rates</ion-text> <ion-icon name=\"caret-down-sharp\" color=\"success\"></ion-icon><ion-icon name=\"caret-up-sharp\" color=\"danger\"></ion-icon><br>\n              <ion-label>0.000 XAF</ion-label><br>\n              <ion-label style=\"font-size: 15px\">aaaa-mm-jj hh:mm</ion-label><br>\n            </ion-label>\n            <!--\n            <ion-label color=\"light\"> \n              <strong> LOCAL BALANCE : 0.00 USD </strong> <br> \n              <strong> JETCAMER BALANCE : 0.00 EUR </strong> <br>\n            </ion-label>\n            <ion-icon name=\"sync\" color=\"light\" size=\"large\"></ion-icon>  \n            -->\n          </ion-button>\n        </ion-col>\n    </ion-row>\n    <ion-row style=\"margin-top: -15px;\">\n      <ion-col size=\"6\">\n        <ion-button expand=\"full\" color=\"success\">\n          <fa-icon icon=\"piggy-bank\" size=\"2x\" slot=\"start\"></fa-icon>\n          <ion-text class=\"action-text\"> &nbsp;<strong>Account</strong><br> &nbsp; <strong>Recharge</strong> </ion-text>\n        </ion-button>\n      </ion-col>\n      <ion-col size=\"6\">\n        <ion-button expand=\"full\" color=\"warning\">\n          <fa-icon icon=\"share-square\" size=\"2x\" slot=\"start\" style=\"color:whitesmoke\"></fa-icon>\n          <ion-label color=\"light\" class=\"action-text\"> &nbsp; <strong>Send</strong> <br> &nbsp; <strong>Money</strong> </ion-label>\n        </ion-button>          \n      </ion-col>\n    </ion-row>\n    </ion-grid>\n  </div>        \n  <div class=\"white-bg-bottom\">\n    <ion-item class=\"footer\">\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"4\">\n            <ion-button class=\"action-button\" fill=\"outlined\">\n              <ion-grid>\n                <ion-row>\n                  <ion-col> <fa-icon icon=\"money-bill-alt\" size=\"2x\"></fa-icon> </ion-col>\n                  <ion-col class=\"action-text\">  <strong>Send Money</strong>  </ion-col>\n                </ion-row>\n              </ion-grid>\n            </ion-button>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-button class=\"action-button\" fill=\"outlined\">\n              <ion-grid>\n                <ion-row>\n                  <ion-col> <fa-icon icon=\"mobile\" size=\"2x\"></fa-icon> </ion-col>\n                  <ion-col class=\"action-text\">  <strong>Air Time</strong> </ion-col>\n                </ion-row>\n              </ion-grid>\n            </ion-button>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-button class=\"action-button\" fill=\"outlined\">\n              <ion-grid>\n                <ion-row>\n                  <ion-col> <ion-icon name=\"print\" size=\"large\" color=\"light\"></ion-icon> </ion-col>\n                  <ion-col class=\"action-text\"> <strong><ion-text>Payment</ion-text></strong>  </ion-col>\n                </ion-row>\n              </ion-grid>\n            </ion-button>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size=\"4\">\n            <ion-button class=\"action-button\" fill=\"outlined\">\n              <ion-grid>\n                <ion-row>\n                  <ion-col> <ion-icon name=\"swap-horizontal\" size=\"large\" color=\"light\"></ion-icon> </ion-col>\n                  <ion-col class=\"action-text\">  <strong>Transfer</strong> </ion-col>\n                </ion-row>\n              </ion-grid>\n            </ion-button>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-button class=\"action-button\" fill=\"outlined\">\n              <ion-grid>\n                <ion-row>\n                  <ion-col> <ion-icon name=\"stats-chart\" size=\"large\" color=\"light\"></ion-icon> </ion-col>\n                  <ion-col class=\"action-text\">  <strong>Transaction</strong> </ion-col>\n                </ion-row>\n              </ion-grid>\n            </ion-button>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-button class=\"action-button\" fill=\"outlined\">\n              <ion-grid>\n                <ion-row>\n                  <ion-col> <ion-icon name=\"card\" size=\"large\" color=\"light\"></ion-icon> </ion-col>\n                  <ion-col class=\"action-text\">  <strong> <ion-text>Buy Credit</ion-text></strong>  </ion-col>\n                </ion-row>\n              </ion-grid>\n            </ion-button>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size=\"4\"> \n            <ion-button class=\"action-button\" fill=\"outlined\">\n              <ion-grid>\n                <ion-row>\n                  <ion-col> <fa-icon icon=\"map-marked\" size=\"2x\"></fa-icon> </ion-col>                \n                  <ion-col class=\"action-text\">  <strong>Local Point</strong> </ion-col>\n                </ion-row>\n              </ion-grid>\n            </ion-button>\n          </ion-col>\n          <ion-col size=\"4\"> \n            <ion-col size=\"4\"> \n              <ion-button class=\"action-button\" fill=\"outlined\">\n                <ion-grid>\n                  <ion-row>\n                    <ion-col> <fa-icon icon=\"wifi\" size=\"2x\"></fa-icon> </ion-col>                \n                    <ion-col class=\"action-text\">  <strong>Network</strong> </ion-col>\n                  </ion-row>\n                </ion-grid>\n              </ion-button>\n            </ion-col>\n          </ion-col>\n          <ion-col size=\"4\">  \n            <ion-button class=\"action-button\" fill=\"outlined\" size=\"small\">     \n              <ion-grid>\n                <ion-row>\n                  <ion-col> <fa-icon icon=\"cart-arrow-down\" size=\"2x\"></fa-icon> </ion-col>                \n                  <ion-col class=\"action-text\"> <strong> <ion-text>Marketplace</ion-text></strong> </ion-col>\n                </ion-row>\n              </ion-grid>\n            </ion-button>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-item>    \n  </div>\n</ion-list>");

/***/ }),

/***/ "./src/app/explore-container/explore-container.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/explore-container/explore-container.component.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-card-header {\n  padding: 1px !important;\n}\n\nion-item {\n  --background: transparent;\n}\n\nion-list {\n  --background: transparent;\n}\n\n.logo {\n  width: 75px;\n  height: 75px;\n  padding-top: 20px;\n}\n\n.box {\n  height: 175px;\n  width: 100%;\n  background: rgba(27, 27, 31, 0.6);\n  padding-top: 20px;\n}\n\n.white-bg-top {\n  background: rgba(255, 255, 255, 0.459);\n}\n\n.white-bg-top .header {\n  margin-top: -10px;\n}\n\n.white-bg-top .footer {\n  float: bottom;\n}\n\n.white-bg-bottom {\n  background: rgba(255, 0, 0, 0.5);\n}\n\n.white-bg-bottom .footer {\n  height: 500px;\n}\n\nion-card {\n  --min-height: 15px;\n}\n\n.vertical-center {\n  height: 60px;\n  width: 60px;\n  margin-left: 40%;\n  margin-top: -25px;\n}\n\n.action-button {\n  height: 60px;\n  width: 110px;\n  color: white;\n}\n\n.action-text {\n  font-size: 12.5px !important;\n}\n\n.container {\n  height: 100%;\n  background-image: url('2.png');\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZXhwbG9yZS1jb250YWluZXIvQzpcXFVzZXJzXFxHYWV0YW4tUHNlXFxEZXNrdG9wXFxHYWV0YW5cXFByb2plY3QgUGVyc29ubmVsXFxteUFwcC9zcmNcXGFwcFxcZXhwbG9yZS1jb250YWluZXJcXGV4cGxvcmUtY29udGFpbmVyLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9leHBsb3JlLWNvbnRhaW5lci9leHBsb3JlLWNvbnRhaW5lci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHVCQUFBO0FDQ0Y7O0FEQ0E7RUFDRSx5QkFBQTtBQ0VGOztBRENBO0VBQ0UseUJBQUE7QUNFRjs7QURBQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUNHRjs7QUREQTtFQUNFLGFBQUE7RUFDQSxXQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQkFBQTtBQ0lGOztBRERBO0VBQ0Msc0NBQUE7QUNJRDs7QURIQztFQUNHLGlCQUFBO0FDS0o7O0FESEU7RUFDRSxhQUFBO0FDS0o7O0FEREE7RUFDRSxnQ0FBQTtBQ0lGOztBREhHO0VBQ0UsYUFBQTtBQ0tMOztBRERBO0VBQ0Usa0JBQUE7QUNJRjs7QUREQTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQ0lGOztBRERBO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FDSUY7O0FEREE7RUFDRSw0QkFBQTtBQ0lGOztBRERBO0VBQ0UsWUFBQTtFQUNBLDhCQUFBO0FDSUYiLCJmaWxlIjoic3JjL2FwcC9leHBsb3JlLWNvbnRhaW5lci9leHBsb3JlLWNvbnRhaW5lci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jYXJkLWhlYWRlcntcbiAgcGFkZGluZzogMXB4ICFpbXBvcnRhbnQ7XG59XG5pb24taXRlbXtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cblxuaW9uLWxpc3R7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG59XG4ubG9nbyB7XG4gIHdpZHRoOiA3NXB4O1xuICBoZWlnaHQ6IDc1cHg7XG4gIHBhZGRpbmctdG9wOiAyMHB4O1xufVxuLmJveHtcbiAgaGVpZ2h0OiAxNzVweDtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQ6IHJnYmEoMjcsMjcsMzEsMC42KTtcbiAgcGFkZGluZy10b3A6IDIwcHg7XG59XG5cbi53aGl0ZS1iZy10b3B7XG4gYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjQ1OSk7XG4gLmhlYWRlciB7XG4gICAgbWFyZ2luLXRvcDogLTEwcHg7IFxuICB9XG4gIC5mb290ZXJ7XG4gICAgZmxvYXQ6IGJvdHRvbTtcbiAgfVxufVxuXG4ud2hpdGUtYmctYm90dG9te1xuICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwwLDAsMC41KTtcbiAgIC5mb290ZXJ7XG4gICAgIGhlaWdodDogNTAwcHg7XG4gIH1cbn1cbiBcbmlvbi1jYXJkIHtcbiAgLS1taW4taGVpZ2h0OiAxNXB4O1xufVxuXG4udmVydGljYWwtY2VudGVye1xuICBoZWlnaHQ6IDYwcHg7XG4gIHdpZHRoOiA2MHB4O1xuICBtYXJnaW4tbGVmdDogNDAlO1xuICBtYXJnaW4tdG9wOiAtMjVweDtcbn1cblxuLmFjdGlvbi1idXR0b24ge1xuICBoZWlnaHQ6IDYwcHg7XG4gIHdpZHRoOiAxMTBweDtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4uYWN0aW9uLXRleHQge1xuICBmb250LXNpemU6IDEyLjVweCAhaW1wb3J0YW50O1xufVxuXG4uY29udGFpbmVye1xuICBoZWlnaHQ6IDEwMCU7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybCguLi8uLi9hc3NldHMvaWNvbi8yLnBuZyk7XG59XG5cbiIsImlvbi1jYXJkLWhlYWRlciB7XG4gIHBhZGRpbmc6IDFweCAhaW1wb3J0YW50O1xufVxuXG5pb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG59XG5cbmlvbi1saXN0IHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cblxuLmxvZ28ge1xuICB3aWR0aDogNzVweDtcbiAgaGVpZ2h0OiA3NXB4O1xuICBwYWRkaW5nLXRvcDogMjBweDtcbn1cblxuLmJveCB7XG4gIGhlaWdodDogMTc1cHg7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kOiByZ2JhKDI3LCAyNywgMzEsIDAuNik7XG4gIHBhZGRpbmctdG9wOiAyMHB4O1xufVxuXG4ud2hpdGUtYmctdG9wIHtcbiAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjQ1OSk7XG59XG4ud2hpdGUtYmctdG9wIC5oZWFkZXIge1xuICBtYXJnaW4tdG9wOiAtMTBweDtcbn1cbi53aGl0ZS1iZy10b3AgLmZvb3RlciB7XG4gIGZsb2F0OiBib3R0b207XG59XG5cbi53aGl0ZS1iZy1ib3R0b20ge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMCwgMCwgMC41KTtcbn1cbi53aGl0ZS1iZy1ib3R0b20gLmZvb3RlciB7XG4gIGhlaWdodDogNTAwcHg7XG59XG5cbmlvbi1jYXJkIHtcbiAgLS1taW4taGVpZ2h0OiAxNXB4O1xufVxuXG4udmVydGljYWwtY2VudGVyIHtcbiAgaGVpZ2h0OiA2MHB4O1xuICB3aWR0aDogNjBweDtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogLTI1cHg7XG59XG5cbi5hY3Rpb24tYnV0dG9uIHtcbiAgaGVpZ2h0OiA2MHB4O1xuICB3aWR0aDogMTEwcHg7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmFjdGlvbi10ZXh0IHtcbiAgZm9udC1zaXplOiAxMi41cHggIWltcG9ydGFudDtcbn1cblxuLmNvbnRhaW5lciB7XG4gIGhlaWdodDogMTAwJTtcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKC4uLy4uL2Fzc2V0cy9pY29uLzIucG5nKTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/explore-container/explore-container.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/explore-container/explore-container.component.ts ***!
  \******************************************************************/
/*! exports provided: ExploreContainerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExploreContainerComponent", function() { return ExploreContainerComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let ExploreContainerComponent = class ExploreContainerComponent {
    constructor() { }
    ngOnInit() { }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ExploreContainerComponent.prototype, "name", void 0);
ExploreContainerComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-explore-container',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./explore-container.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/explore-container/explore-container.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./explore-container.component.scss */ "./src/app/explore-container/explore-container.component.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], ExploreContainerComponent);



/***/ }),

/***/ "./src/app/explore-container/explore-container.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/explore-container/explore-container.module.ts ***!
  \***************************************************************/
/*! exports provided: ExploreContainerComponentModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExploreContainerComponentModule", function() { return ExploreContainerComponentModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fortawesome/angular-fontawesome */ "./node_modules/@fortawesome/angular-fontawesome/fesm2015/angular-fontawesome.js");
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fortawesome/free-solid-svg-icons */ "./node_modules/@fortawesome/free-solid-svg-icons/index.es.js");
/* harmony import */ var _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fortawesome/free-brands-svg-icons */ "./node_modules/@fortawesome/free-brands-svg-icons/index.es.js");
/* harmony import */ var _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @fortawesome/free-regular-svg-icons */ "./node_modules/@fortawesome/free-regular-svg-icons/index.es.js");
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @fortawesome/fontawesome-svg-core */ "./node_modules/@fortawesome/fontawesome-svg-core/index.es.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _explore_container_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./explore-container.component */ "./src/app/explore-container/explore-container.component.ts");











_fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_8__["library"].add(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_5__["fas"], _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_6__["fab"], _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__["far"]);
let ExploreContainerComponentModule = class ExploreContainerComponentModule {
};
ExploreContainerComponentModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_4__["FontAwesomeModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_9__["IonicModule"]],
        declarations: [_explore_container_component__WEBPACK_IMPORTED_MODULE_10__["ExploreContainerComponent"]],
        exports: [_explore_container_component__WEBPACK_IMPORTED_MODULE_10__["ExploreContainerComponent"]]
    })
], ExploreContainerComponentModule);



/***/ })

}]);
//# sourceMappingURL=default~tab1-tab1-module~tab2-tab2-module~tab3-tab3-module-es2015.js.map